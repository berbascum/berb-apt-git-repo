#!/bin/bash

# Upstream-Name: berb-droidian-build-docker-mgr
# Source: https://github.com/droidian-berb/berb-droidian-build-docker-mgr
  ## Script to configure a debian package to be builded with the droidian releng-tools

# Copyright (C) 2024 Berbascum <berbascum@ticv.cat>
# All rights reserved.

# BSD 3-Clause License
#
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#    * Neither the name of the <organization> nor the
#      names of its contributors may be used to endorse or promote products
#      derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


info() { echo; echo "$*"; }
error() { echo; echo "$*"; exit 1; }
abort() { echo; echo "$*"; exit 10; }
ask() { echo; read -p "$*" answer; }

[ -z "$(echo "$*" | grep "\-\-run")" ] && abort "The script tag --run is required!"

fn_set_target_arch() {
    cfg_file="bdm-build.conf"
    if [ ! -f "${cfg_file}" ]; then
        error "File ${cfg_file} missing"
    fi
    BDM_BUILD_TARGET_ARCH="$(cat ${cfg_file} | grep "BDM_BUILD_TARGET_ARCH" | awk -F'=' '{print $2}')"
    err_msg="Please configure BDM_BUILD_TARGET_ARCH in  the ${err_msg} file"
    [ "${BDM_BUILD_TARGET_ARCH}" == "REPLACE" ] && abort "${err_msg}"
    [ -z "${BDM_BUILD_TARGET_ARCH}" ] && abort "${err_msg}"
    target_arch="${BDM_BUILD_TARGET_ARCH}"
}

fn_required_dirs() {
    ## We should be in the sources dir
    sources_dir="/buildd/sources"
    cd ${sources_dir}
    [ "$(pwd)" == "${sources_dir}" ] || error "Current dir is not \"${sources_dir}\""
    ## We should be in a git repo dir
    [ -d ".git" ] || error "Current dir should be a git repo!"
}

fn_git_workdir_status_check() {
    [ -n "$(git status | grep "staged")" ] && abort "The git workdir is not clean!"
}

fn_git_get_last_tag() {
    ## Get last tag info for releng
    last_tag=$(git tag --sort=-creatordate | sed -n '1p')
    tag_prefix=$(echo "${last_tag}" | awk -F'/' '{print $1}')
    echo "last_git tag: ${last_tag}"
}

fn_config_global() {
    chmod +x /buildd/sources/debian/rules
    cd /buildd/sources
    package_name=$(cat debian/control | grep "^Source: " | head -n 1 | awk '{print $2}')
}

fn_install_releng_tools() {
    apt-get update \
        && apt-get install -y releng-tools
}

fn_build_package() {
    ## Call releng
    git config --global \
       --add safe.directory /buildd/sources

    RELENG_FULL_BUILD="yes" \
        RELENG_TAG_FULL="${last_tag}" \
        RELENG_TAG_PREFIX="${tag_prefix}/" \
        RELENG_HOST_ARCH="${target_arch}" \
        DEB_BUILD_OPTIONS=nocheck \
        releng-build-package
}

## Check directory requirements
fn_required_dirs
fn_set_target_arch
fn_git_get_last_tag
## Load global conf
fn_config_global
fn_install_releng_tools
## Check the git workdir status and abort if not clean
fn_git_workdir_status_check
## Check if the last commit has a tag
#fn_set_last_tag
## Get package info
## Call releng-build-package
fn_build_package
