//===----------------------------------------------------------------------===/
//                          Kaleidoscope with MCJIT
//===----------------------------------------------------------------------===//

The files in this directory are accompany a series of blog posts that describe 
the process of porting the Kaleidoscope tutorial to use the MCJIT execution 
engine instead of the older JIT engine.


