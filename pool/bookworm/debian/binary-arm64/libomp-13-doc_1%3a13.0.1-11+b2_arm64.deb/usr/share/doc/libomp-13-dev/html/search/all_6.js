var searchData=
[
  ['ident_0',['ident',['../structident.html',1,'']]],
  ['ident_5ft_1',['ident_t',['../group__BASIC__TYPES.html#gabaf9a1671d9d5fe8d98cf00157cac2aa',1,'kmp.h']]]
];
