var searchData=
[
  ['wait_2frelease_20operations_0',['Wait/Release operations',['../group__WAIT__RELEASE.html',1,'']]],
  ['work_20sharing_1',['Work Sharing',['../group__WORK__SHARING.html',1,'']]]
];
