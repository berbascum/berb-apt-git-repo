var searchData=
[
  ['ident_0',['ident',['../structident.html',1,'']]]
];
