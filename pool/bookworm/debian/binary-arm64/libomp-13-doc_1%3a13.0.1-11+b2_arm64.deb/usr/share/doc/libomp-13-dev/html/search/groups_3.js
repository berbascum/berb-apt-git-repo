var searchData=
[
  ['parallel_20_28fork_2fjoin_29_0',['Parallel (fork/join)',['../group__PARALLEL.html',1,'']]]
];
