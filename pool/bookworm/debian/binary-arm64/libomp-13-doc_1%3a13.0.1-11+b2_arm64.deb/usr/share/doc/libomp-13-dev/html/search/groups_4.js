var searchData=
[
  ['startup_20and_20shutdown_0',['Startup and Shutdown',['../group__STARTUP__SHUTDOWN.html',1,'']]],
  ['statistics_20gathering_20from_20omptb_1',['Statistics Gathering from OMPTB',['../group__STATS__GATHERING.html',1,'']]],
  ['synchronization_2',['Synchronization',['../group__SYNCHRONIZATION.html',1,'']]]
];
