var searchData=
[
  ['onlyinmaster_0',['onlyInMaster',['../group__STATS__GATHERING.html#gga438c2840cc2d516238ea3eb0f4c116b3ab1b2cd818808a4ee2cc1720286fbc51d',1,'kmp_stats.h']]],
  ['open_1',['open',['../classkmp__safe__raii__file__t.html#af32c80a67905ff01adb13dd546906f96',1,'kmp_safe_raii_file_t']]]
];
